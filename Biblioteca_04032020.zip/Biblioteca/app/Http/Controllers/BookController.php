<?php

namespace App\Http\Controllers;

use App\Models\Author;
use App\Models\Book;
use Illuminate\Http\Request;
use Validator;
use DB;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $path = 'images/books';
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $books = Book::get();
        $authors = Author::get();
        $selected_aut = [];

        return view('book.index', compact('books', 'authors', 'selected_aut'));
    }
    public function add()
    {
        $authors = Author::get();
        return view('book.add', compact('authors'));
    }


    public function save(Request $request)
    {
        if (!empty($request->file('image')) && $request->file('image')->isValid()) {
            $fileName = time() . '.' . $request->file('image')->getClientOriginalExtension();
            $request->file('image')->move($this->path, $fileName);
        }

        $validator = Validator::make($request->all(), [
                    'title' => 'required|min:5|max:255',
                    'description' => 'required'
                ]);

                if (!$validator->fails()) {
                   
                    $book = Book::create([
                        'title' => $request->input('title'),
                        'description' => $request->input('description'),
                        'image' => $fileName
                    ]);
        
                    
                    $book->authors()->sync($request->input('author'));
                }
                return redirect()->route('book.index');

    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $book = Book::find($id);

        if (!empty($book)) {
            $authors = Author::get();
           
            $selected_aut = array();

            foreach ($book->authors as $author) {
                $selected_aut[] = $author->pivot->author_id;
            }
            return view('book.edit', compact(
                'book',
                'authors',
                'selected_aut'
            ));
        }

        return redirect()->route('book.index');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       // $images = $request->file('images');
        $author = $request->input('author');

        $book = Book::find($id);

        if (!empty($book)) {
            $fileName = null;
        if (!empty($request->file('image')) && $request->file('image')->isValid()) {
            if (!empty($request->input('deleteimage')) && file_exists($this->path . '/' . $request->input('deleteimage'))) {
                unlink($this->path . '/' . $request->input('deleteimage'));
            }
            $fileName = time() . '.' . $request->file('image')->getClientOriginalExtension();
            $request->file('image')->move($this->path, $fileName);
        }

            if (!empty($author)) {
                $book->categories()->sync($author);
            }
            if (!$fileName) {
            $book->update([
                'title' =>  $request->input('title'),
                'description' =>  $request->input('description')

            ]);
            }else{
                $book->update([
                    'title' =>  $request->input('title'),
                    'description' =>  $request->input('description'),
                    'image' => $fileName
    
                ]);

            }
    }

        return redirect()->route('book.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $book = Book::find($id);

        if (!empty($book)) {
            
            $book->authors()->detach();
            $result = $book->delete();
        }

        return redirect()->route('book.index');
    }
    public function search(Request $request)
    {

        $title = $request->input('title');
        $selected_aut = $request->input('author');

        $search = TRUE;

        $query = DB::table('books')->select('books.id', 'books.title', 'books.description')
            ->join('books_authors', 'books.id', '=', 'books_authors.book_id')
            ->join('authors', 'books_authors.author_id', '=', 'authors.id')
            ->groupBy('books.id', 'books.title', 'books.description');

        if (!empty($title) && !empty($selected_aut)) {
            $query->where('books.title', 'like', '%' . $title . '%');

            $query->whereIn('authors.id', $selected_aut);
        } else if (!empty($title)) {
            $query->where('books.title', 'like', '%' . $title . '%');
        } else if (!empty($selected_aut)) {
            $query->whereIn('authors.id', $selected_aut);
        }

        $authors = Author::get();
        $books = $query->get();

        if (empty($selected_aut)) {
            $selected_aut = [];
        }
        return view('book.index', compact('books', 'authors', 'selected_aut', 'search'));
    }
}
