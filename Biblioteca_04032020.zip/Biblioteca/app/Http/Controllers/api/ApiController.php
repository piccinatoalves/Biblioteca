<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Validator;
use Storage;

class ApiController extends Controller
{
    public function products()
    {
        $products = Product::with(['categories', 'images'])->get();
        return response()->json($products);
    }

    public function categories()
    {
        $categories = Product::with(['categories', 'images'])->get();
        return response()->json($categories);
    }

    public function saveCategories(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:10|max:255',
            'url_image' => 'required',
        ]);

        $name = $request->input('name');
        $url = $request->input('url_image');

        $validator = Validator::make($request->all(), [
            'name' => 'required|min:10',
            'url_image' => 'required'
        ]);

        $name = $request->input('name');
        $url = $request->input('url_image');

        if (!$validator->fails()) {
            $contents = file_get_contents($url);
            $namefile = time() . '.' . substr($url, strrpos($url, ".") + 1);
            Storage::disk("public")->put($namefile, $contents);

            $category = Category::create([
                'name' => $name,
                'image' => $namefile
            ]);

            if (!empty($category)) {
                return response()->json($category);
            }
        }

        return response()->json([
            "message" => 'Erro ao salvr categoria',
            "erros" => $validator->errors()
        ], 500);
    }
}
